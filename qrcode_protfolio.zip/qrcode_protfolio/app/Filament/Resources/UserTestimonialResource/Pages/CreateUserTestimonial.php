<?php

namespace App\Filament\Resources\UserTestimonialResource\Pages;

use App\Filament\Resources\UserTestimonialResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateUserTestimonial extends CreateRecord
{
    protected static string $resource = UserTestimonialResource::class;
}
