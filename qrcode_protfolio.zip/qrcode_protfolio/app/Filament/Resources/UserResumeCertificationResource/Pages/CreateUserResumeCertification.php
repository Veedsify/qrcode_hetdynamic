<?php

namespace App\Filament\Resources\UserResumeCertificationResource\Pages;

use App\Filament\Resources\UserResumeCertificationResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateUserResumeCertification extends CreateRecord
{
    protected static string $resource = UserResumeCertificationResource::class;
}
