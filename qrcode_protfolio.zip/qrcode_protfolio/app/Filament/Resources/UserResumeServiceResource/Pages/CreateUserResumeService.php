<?php

namespace App\Filament\Resources\UserResumeServiceResource\Pages;

use App\Filament\Resources\UserResumeServiceResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateUserResumeService extends CreateRecord
{
    protected static string $resource = UserResumeServiceResource::class;
}
