<?php

namespace App\Filament\Resources\UserResumeResource\Pages;

use App\Filament\Resources\UserResumeResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateUserResume extends CreateRecord
{
    protected static string $resource = UserResumeResource::class;
}
