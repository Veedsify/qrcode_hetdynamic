<?php

namespace App\Filament\Resources\UserResumeEducationResource\Pages;

use App\Filament\Resources\UserResumeEducationResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateUserResumeEducation extends CreateRecord
{
    protected static string $resource = UserResumeEducationResource::class;
}
